class Info:
    def __init__(self, course_id, course_image, course_name, teachers, contacts):
        self.course_id = course_id
        self.course_image = course_image
        self.course_name = course_name
        self.teachers = teachers
        self.contacts = contacts
