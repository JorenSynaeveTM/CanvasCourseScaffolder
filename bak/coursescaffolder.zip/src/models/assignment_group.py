class AssignmentGroup:
    def __init__(self, name, weight):
        self.id = None
        self.name = name
        self.weight = weight
